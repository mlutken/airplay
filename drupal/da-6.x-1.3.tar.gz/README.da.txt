Danish translation of Drupal interface strings.

Copyright 2004-2010 Morten Wulff <wulff@ratatosk.net>

Based on the wordlist provided by Commercial Linux Association of Denmark (KLID, http://www.klid.dk/dansk/ordlister/ordliste.html), SSLUG (Skåne Sjælland Linux User Group, http://www.sslug.dk/locale/oversaet/ordlister/) and It-terminologi-udvalget (http://www.it-dansk.dk/).


CONTRIBUTING

If you want to help translate Drupal and contributed modules to Danish, simply create an account on http://localize.drupal.org/ and submit your translated strings.


CONTRIBUTORS

Lennart Kiil <lennart@zensci.com>
Bjarne Andersen <bjarne@6400.net>
Frederik 'Freso' S. Olesen <freso.dk@gmail.com>
Steven Snedker <ss@vertikal.dk>

benjamin.ravn      http://localize.drupal.org/user/1389
marcushenningsen   http://localize.drupal.org/user/2348
kaerast            http://localize.drupal.org/user/2522
c960657            http://localize.drupal.org/user/7146
Uv516              http://localize.drupal.org/user/1020
tlyngej            http://localize.drupal.org/user/5642
Hylle              http://localize.drupal.org/user/33518
arlind             http://localize.drupal.org/user/5536


TRANSLATED MODULES

Please consult the status page at http://ratatosk.backpackit.com/pub/1829473-drupal-p-dansk to see the current translation status of contributed modules. If your favorite module is not on the list, please contact me and I'll add it.


WORDLIST

The current wordlist and links to translation tools are available at http://ratatosk.backpackit.com/pub/1831018-drupal-p-dansk. 


CURRENT SPONSOR

Peytz & Co. A/S


PREVIOUS SPONSORS

Berlingske Media A/S


$Id: README.txt,v 1.11.2.7 2010/05/04 09:22:55 wulff Exp $
