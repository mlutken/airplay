-- phpMyAdmin SQL Dump
-- version 3.1.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 28, 2010 at 09:22 PM
-- Server version: 5.0.67
-- PHP Version: 5.2.12

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `airplay_music`
--

-- --------------------------------------------------------

--
-- Table structure for table `album`
--

DROP TABLE IF EXISTS `album`;
CREATE TABLE IF NOT EXISTS `album` (
  `album_id` int(10) unsigned NOT NULL auto_increment,
  `artist_id` int(10) unsigned NOT NULL,
  `album_name` varchar(256) NOT NULL,
  `record_label_id` int(6) unsigned NOT NULL,
  `genre_id` tinyint(4) unsigned NOT NULL default '0',
  `subgenre_id` smallint(4) unsigned NOT NULL default '0',
  `album_year` smallint(4) unsigned NOT NULL default '0',
  `album_status` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`album_id`),
  KEY `artist_id` (`artist_id`,`record_label_id`),
  KEY `album_name` (`album_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `album`
--


-- --------------------------------------------------------

--
-- Table structure for table `album_song_rel`
--

DROP TABLE IF EXISTS `album_song_rel`;
CREATE TABLE IF NOT EXISTS `album_song_rel` (
  `album_song_rel_id` int(10) unsigned NOT NULL auto_increment,
  `album_id` int(10) unsigned NOT NULL default '0',
  `song_id` int(10) unsigned NOT NULL default '0',
  `track_number` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`album_song_rel_id`),
  KEY `album_id` (`album_id`,`song_id`),
  KEY `song_id` (`song_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `album_song_rel`
--


-- --------------------------------------------------------

--
-- Table structure for table `artist`
--

DROP TABLE IF EXISTS `artist`;
CREATE TABLE IF NOT EXISTS `artist` (
  `artist_id` int(10) unsigned NOT NULL auto_increment,
  `artist_name` varchar(256) NOT NULL,
  `artist_url` varchar(256) NOT NULL,
  `genre_id` tinyint(3) unsigned NOT NULL default '0',
  `subgenre_id` smallint(3) unsigned NOT NULL default '0',
  `country_id` smallint(6) default '0',
  `artist_status` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`artist_id`),
  KEY `artist_name` (`artist_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `artist`
--


-- --------------------------------------------------------

--
-- Table structure for table `artist_synonym`
--

DROP TABLE IF EXISTS `artist_synonym`;
CREATE TABLE IF NOT EXISTS `artist_synonym` (
  `artist_synonym_id` int(10) unsigned NOT NULL auto_increment,
  `artist_synonym_name` varchar(256) NOT NULL default '',
  `artist_id` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`artist_synonym_id`),
  KEY `artist_synonym_name` (`artist_synonym_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `artist_synonym`
--


-- --------------------------------------------------------

--
-- Table structure for table `buy_album`
--

DROP TABLE IF EXISTS `buy_album`;
CREATE TABLE IF NOT EXISTS `buy_album` (
  `buy_album_id` int(11) NOT NULL auto_increment,
  `album_id` int(10) unsigned NOT NULL,
  `record_store_id` int(10) unsigned NOT NULL,
  `media_format_id` tinyint(3) unsigned NOT NULL,
  `price_local` int(11) NOT NULL,
  `currency_id` tinyint(3) unsigned NOT NULL,
  `buy_at_url` varchar(256) NOT NULL,
  `timestamp_updated` timestamp NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`buy_album_id`),
  KEY `album_id` (`album_id`),
  KEY `record_store_id` (`record_store_id`),
  KEY `media_format_id` (`media_format_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `buy_album`
--


-- --------------------------------------------------------

--
-- Table structure for table `buy_album_history`
--

DROP TABLE IF EXISTS `buy_album_history`;
CREATE TABLE IF NOT EXISTS `buy_album_history` (
  `buy_album_id` int(11) NOT NULL,
  `price_local` int(11) NOT NULL,
  `currency_id` tinyint(4) NOT NULL,
  `timestamp_updated` timestamp NULL default '0000-00-00 00:00:00'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `buy_album_history`
--


-- --------------------------------------------------------

--
-- Table structure for table `buy_song`
--

DROP TABLE IF EXISTS `buy_song`;
CREATE TABLE IF NOT EXISTS `buy_song` (
  `buy_song_id` int(11) NOT NULL auto_increment,
  `song_id` int(10) unsigned NOT NULL,
  `record_store_id` int(10) unsigned NOT NULL,
  `media_format_id` tinyint(3) unsigned NOT NULL,
  `price_local` int(11) NOT NULL,
  `currency_id` tinyint(3) unsigned NOT NULL,
  `buy_at_url` varchar(256) NOT NULL,
  `timestamp_updated` timestamp NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`buy_song_id`),
  KEY `song_id` (`song_id`),
  KEY `record_store_id` (`record_store_id`),
  KEY `media_format_id` (`media_format_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `buy_song`
--


-- --------------------------------------------------------

--
-- Table structure for table `buy_song_history`
--

DROP TABLE IF EXISTS `buy_song_history`;
CREATE TABLE IF NOT EXISTS `buy_song_history` (
  `buy_song_id` int(11) NOT NULL,
  `price_local` int(11) NOT NULL,
  `currency_id` tinyint(4) NOT NULL,
  `timestamp_updated` timestamp NULL default '0000-00-00 00:00:00'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `buy_song_history`
--


-- --------------------------------------------------------

--
-- Table structure for table `country`
--

DROP TABLE IF EXISTS `country`;
CREATE TABLE IF NOT EXISTS `country` (
  `country_id` tinyint(3) NOT NULL,
  `country_name` varchar(256) NOT NULL,
  PRIMARY KEY  (`country_id`),
  KEY `country_name` (`country_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `country`
--

INSERT INTO `country` (`country_id`, `country_name`) VALUES
(45, 'Denmark'),
(46, 'Sweden');

-- --------------------------------------------------------

--
-- Table structure for table `currency`
--

DROP TABLE IF EXISTS `currency`;
CREATE TABLE IF NOT EXISTS `currency` (
  `currency_id` tinyint(3) unsigned NOT NULL auto_increment,
  `currency_name` char(4) NOT NULL,
  PRIMARY KEY  (`currency_id`),
  KEY `currency_name` (`currency_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `currency`
--

INSERT INTO `currency` (`currency_id`, `currency_name`) VALUES
(1, 'EUR'),
(2, 'DKK'),
(3, 'SEK');

-- --------------------------------------------------------

--
-- Table structure for table `distribution_form`
--

DROP TABLE IF EXISTS `distribution_form`;
CREATE TABLE IF NOT EXISTS `distribution_form` (
  `distribution_form_id` tinyint(3) unsigned NOT NULL auto_increment,
  `distribution_form_name` varchar(30) NOT NULL,
  PRIMARY KEY  (`distribution_form_id`),
  KEY `distribution_form_name` (`distribution_form_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `distribution_form`
--

INSERT INTO `distribution_form` (`distribution_form_id`, `distribution_form_name`) VALUES
(1, 'retail'),
(2, 'e-trade');

-- --------------------------------------------------------

--
-- Table structure for table `genre`
--

DROP TABLE IF EXISTS `genre`;
CREATE TABLE IF NOT EXISTS `genre` (
  `genre_id` tinyint(3) unsigned NOT NULL auto_increment,
  `genre_name` varchar(40) NOT NULL,
  PRIMARY KEY  (`genre_id`),
  KEY `genre_name` (`genre_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `genre`
--

INSERT INTO `genre` (`genre_id`, `genre_name`) VALUES
(1, 'Pop/Rock'),
(2, 'Soul/R&B'),
(3, 'Dance/Electronic'),
(4, 'HipHop/Rap'),
(5, 'Metal/Hard Rock'),
(6, 'Country/Folk'),
(7, 'Jazz/Blues'),
(8, 'Classical'),
(9, 'Entertainment'),
(10, 'Kids'),
(11, 'Other'),
(12, 'New age'),
(13, 'World/Reggae'),
(14, 'Soundtrack');

-- --------------------------------------------------------

--
-- Table structure for table `integers`
--

DROP TABLE IF EXISTS `integers`;
CREATE TABLE IF NOT EXISTS `integers` (
  `i` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`i`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `integers`
--

INSERT INTO `integers` (`i`) VALUES
(0),
(1),
(2),
(3),
(4),
(5),
(6),
(7),
(8),
(9);

-- --------------------------------------------------------

--
-- Table structure for table `media_format`
--

DROP TABLE IF EXISTS `media_format`;
CREATE TABLE IF NOT EXISTS `media_format` (
  `media_format_id` tinyint(3) unsigned NOT NULL auto_increment,
  `media_format_name` varchar(30) NOT NULL,
  PRIMARY KEY  (`media_format_id`),
  KEY `media_format_name` (`media_format_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `media_format`
--

INSERT INTO `media_format` (`media_format_id`, `media_format_name`) VALUES
(1, 'WMA'),
(2, 'ACC'),
(3, 'MP3'),
(4, 'Stream'),
(5, 'CD'),
(6, 'Single'),
(7, 'Vinyl'),
(8, 'DVD'),
(9, 'Mobile'),
(10, 'Blu-ray');

-- --------------------------------------------------------

--
-- Table structure for table `record_label`
--

DROP TABLE IF EXISTS `record_label`;
CREATE TABLE IF NOT EXISTS `record_label` (
  `record_label_id` int(10) unsigned NOT NULL auto_increment,
  `record_label_name` varchar(128) NOT NULL,
  `record_label_url` varchar(80) NOT NULL,
  PRIMARY KEY  (`record_label_id`),
  KEY `record_label_name` (`record_label_name`),
  KEY `record_label_name_2` (`record_label_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `record_label`
--


-- --------------------------------------------------------

--
-- Table structure for table `record_store`
--

DROP TABLE IF EXISTS `record_store`;
CREATE TABLE IF NOT EXISTS `record_store` (
  `record_store_id` int(10) unsigned NOT NULL auto_increment,
  `record_store_name` varchar(128) NOT NULL,
  `record_store_url` varchar(80) NOT NULL,
  `country_id` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`record_store_id`),
  KEY `record_store_name` (`record_store_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `record_store`
--


-- --------------------------------------------------------

--
-- Table structure for table `song`
--

DROP TABLE IF EXISTS `song`;
CREATE TABLE IF NOT EXISTS `song` (
  `song_id` int(10) unsigned NOT NULL auto_increment,
  `song_name` varchar(256) NOT NULL,
  `artist_id` int(10) unsigned NOT NULL default '0',
  `record_label_id` int(10) unsigned NOT NULL default '0',
  `genre_id` tinyint(4) unsigned NOT NULL default '0',
  `subgenre_id` smallint(3) unsigned NOT NULL default '0',
  `song_year` smallint(4) unsigned NOT NULL default '0',
  `song_time` smallint(5) unsigned NOT NULL default '0',
  `song_status` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`song_id`),
  KEY `song_name` (`song_name`),
  KEY `artist_id` (`artist_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `song`
--


-- --------------------------------------------------------

--
-- Table structure for table `subgenre`
--

DROP TABLE IF EXISTS `subgenre`;
CREATE TABLE IF NOT EXISTS `subgenre` (
  `subgenre_id` smallint(5) unsigned NOT NULL auto_increment,
  `subgenre_name` varchar(40) NOT NULL,
  PRIMARY KEY  (`subgenre_id`),
  KEY `genre_name` (`subgenre_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `subgenre`
--

