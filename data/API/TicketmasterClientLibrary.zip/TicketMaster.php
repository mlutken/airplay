<?php
/**
 *
 * Ticketmaster API Client
 *
 * Copyright (C) 2011-2012 Digital Window Ltd.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

namespace TicketMaster;

/**
 * Ticket master client class
 */
class Client
{
    /**
     * @var array
     */
    protected static $_countries = array(
        'UK' => 3589, 
        'US' => 4103, 
        'CA' => 4103
    );
    
    /**
     * @const string
     */
    const WSDL = 'http://ticketmaster.productserve.com/v2/soap.php?wsdl';

    /**
     * @var \SoapClient
     */
    protected $_soapClient;

    /**
     * @var string
     */
    protected $_apiKey;
    
    /**
     * @var integer
     */
    protected $_affiliateId;
    
    /**
     * @var string
     */
    protected $_country;

    /**
     * @param integer $affiliateId
     * @param string $apiKey
     * @param string country
     */
    public function __construct($affiliateId, $apiKey, $country)
    {
        $this->_affiliateId = (int)$affiliateId;
        $this->_apiKey = $apiKey;
        $country = strtoupper($country);
        if (! in_array($country, array_keys(static::$_countries))) {
            throw new \TicketMaster\Exception("Invalid country: " . $country);
        }
        $this->_country = $country;
    }

    /**
     * @return \TicketMaster\Request 
     */
    public function findEvents()
    {
        return new \TicketMaster\Request($this);
    }

    /**
     * return \SoapClient
     */
    public function getSoapClient()
    {
        if (! $this->_soapClient) {
            $this->_soapClient = new \SoapClient(self::WSDL); 
        }

        return $this->_soapClient;
    }

    /**
     * @return string
     */
    public function getApiKey()
    {
        return $this->_apiKey;
    }
    
    /**
     * @return string
     */
    public function getCountry()
    {
        return $this->_country;
    }
    
    /**
     * @param string $url
     * @param string $clickref
     * @return string
     */
    public function deeplink($url, $clickref = '')
    {
        $country = $this->getCountry();
        $merchantId = static::$_countries[$country];
        $affiliateId = $this->_affiliateId;
        
        $deeplink = "http://www.awin1.com/awclick.php?awinmid=" . $merchantId . "&awinaffid=" . $affiliateId
            . "&platform=tm";
          
        if ($clickref) {
          $deeplink .= "&clickref=" . $clickref;
        }

        $deeplink .= "&p=" . urlencode($url);
        
        return $deeplink;
    }
}

/**
 * Ticket Master request class
 */
class Request
{
    /**
     * @var \TicketMaster\Client
     */
    protected $_client;

    /**
     * @var \TicketMaster\Payload
     */
    protected $_payload;

    /**
     * @param \TicketMaster\Client $client
     * @param string $country
     */
    public function __construct(\TicketMaster\Client $client)
    {
        $country = $client->getCountry();
        $this->_client = $client;
        $this->_payload = new \TicketMaster\Payload();
        $this->_payload->apiKey = $client->getApiKey();
        $this->_payload->country = $country;
    }

    /**
     * Filter by artist
     * 
     * @param string $field
     * @param mixed $values
     * @return \TicketMaster\Request
     */
    public function artist($field, $values)
    {
        $this->_filter('artist', $field, $values);
        return $this;
    }

    /**
     * Filter by event
     * 
     * @param string $field
     * @param mixed $values
     * @return \TicketMaster\Request
     */
    public function event($field, $values)
    {
        $this->_filter('event', $field, $values);
        return $this;
    }
    
    /**
     * Filter by venue
     * 
     * @param string $field
     * @param mixed $values
     * @return \TicketMaster\Request
     */
    public function venue($field, $values)
    {
        $this->_filter('venue', $field, $values);
        return $this;
    }

    /**
     * @param string $object
     * @param string $field
     * @param mixed $values
     */
    protected function _filter($object, $field, $values)
    {
        $validFields = array(
            'artist' => array('name', 'ticketmasterArtistId', 'categoryId', 'parentCategoryId'),
            'venue' => array('ticketmasterVenueId', 'name', 'postcode', 'city', 'state'),
            'event' => array('ticketmasterEventId', 'categoryId', 'parentCategoryId', 'status')
        );

        if (! in_array($field, $validFields[$object])) {
            throw new \TicketMaster\Exception("Invalid filter field for $object: $field");
        }
        
        if (! is_array($values)) {
            $values = (array)$values;
        }

        if (empty($values)) {
            throw new \TicketMaster\Exception("No value(s) provided for filter");
        }

        $filter = new \stdClass();
        $filter->object = $object;
        $filter->field = $field;
        $filter->values = $values;

        $this->_payload->filters[] = $filter;
    }

    /**
     * @param \DateTime $date
     * @return \TicketMaster\Request
     */
    public function since(\DateTime $date)
    {
        $this->_payload->updatedSince = $date->format('Y-m-d H:i:s');
        return $this;
    }

    /**
     * @param string $field
     * @param string $order
     * @return \TicketMaster\Request
     */
    public function sort($field, $order = 'ASC')
    {
        $sortableFields = array('name', 'eventDate', 'onSaleDate', 'preSaleDate', 'categoryId',
            'minPrice', 'maxPrice', 'lastUpdated');

        if (! in_array($field, $sortableFields)) {
            throw new \TicketMaster\Exception("Invalid sort field: $field");
        }

        $order = strtoupper($order);
        if (! in_array($order, array('ASC', 'DESC'))) {
            throw new \TicketMaster\Exception("Invalid sort order: $order");
        }
        
        $sort = new \stdClass();
        $sort->field = $field;
        $sort->order = $order;
        
        $this->_payload->sort = $sort;
        return $this;
    }

    /**
     * @param integer $pageNumber
     * @param integer $itemsPerPage
     */
    public function fetch($pageNumber = 1, $itemsPerPage = 50)
    {
        $itemsPerPage = (int)$itemsPerPage ? : 50;
        $pageNumber = (int)$pageNumber ? : 1;

        if ($itemsPerPage > 100) {
            throw new \TicketMaster\Exception("Limit of 100 items per page exceeded");
        }

        $this->_payload->currentPage = $pageNumber;
        $this->_payload->resultsPerPage = $itemsPerPage;

        return $this->_client->getSoapClient()->__soapCall('findEvents', array($this->_payload));
    }
}

/**
 * SOAP payload
 */
class Payload
{
    /**
     * @var string
     */
    public $apiKey = '';
    
    /** 
     * @var string
     */
    public $country;
    
    /** 
     * @var integer
     */
    public $resultsPerPage = 50;
    
    /**
     * @var integer
     */
    public $currentPage = 1;
    
    /**
     * @var stdClass
     */
    public $sort;
    
    /**
     * @var stdClass[]
     */
    public $filters = array();
    
    /**
     * @var string
     */
    public $updatedSince;
}

/**
 * TicketMaster exception
 */
class Exception extends \Exception
{
    
}